from datetime import datetime
import haversine as hs
import numpy as np


def distance(lat1, lon1, lat2, lon2):
    loc1 = (lat1, lon1)
    loc2 = (lat2, lon2)
    dist1 = hs.haversine(loc1, loc2)
    return dist1

def compute_speed(prev_tmstmp, curr_tmstmp, distnce):
    """ Compute speed of the track in kts
        (using distance in km and time in seconds between two frames) """

    prev_dt_obj = datetime.fromtimestamp(prev_tmstmp)  # "timeStamp" parameter from metadata of previous frame
    curr_dt_obj = datetime.fromtimestamp(curr_tmstmp)  # "timeStamp" parameter from metadata of current frame
    time_diff_sec = (curr_dt_obj - prev_dt_obj).total_seconds()
    speed_kts = distnce * 1944 / time_diff_sec
    return speed_kts


################################################ Example #######################################################

prev_frme = {"messageType": "UAV1", "isNewTrack": "0", "trackId": "UAVtbvqm", "trackName": "UAVtbvqm555141",
             "latitude": 5.317715995627324, "longitude": 86.38431799895329, "course": 289.26891536896153,
             "timeStamp": 1679055514, "speed": 4.584822, "height": "0", "sensorDatetime": 1679055514,
             "trackType": "CARGO", "trackQuality": "1", "header": "$PRTRK", "anomalyStatus": "true", "status": "0",
             "anomalyCodeList": [], "isT0Track": "false", "iffFlag": "U"}

curr_frme = {"messageType": "UAV1", "isNewTrack": "0", "trackId": "UAVtbvqm", "trackName": "UAVtbvqm555161",
             "latitude": 5.317683934847679, "longitude": 86.38442721515167, "course": 289.27210766704724,
             "timeStamp": 1679055516, "speed": 5.279861, "height": "0", "sensorDatetime": 1679055516,
             "trackType": "CARGO", "trackQuality": "1", "header": "$PRTRK", "anomalyStatus": "true", "status": "0",
             "anomalyCodeList": [], "isT0Track": "false", "iffFlag": "U"}


prev_lat = prev_frme["latitude"]
prev_lon = prev_frme["longitude"]
curr_lat = curr_frme["latitude"]
curr_lon = curr_frme["longitude"]

prev_tmstmp = prev_frme["timeStamp"]
curr_tmstmp = curr_frme["timeStamp"]

distnce = np.round(distance(prev_lat, prev_lon, curr_lat, curr_lon), 3)
speed = compute_speed(prev_tmstmp, curr_tmstmp, distnce)

print(f"Distance : {distnce} km")
print(f"Speed : {speed} kts")
