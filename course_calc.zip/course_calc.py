from math import radians, degrees, atan2, sin, cos
import numpy as np


def compute_course(lat1, lon1, lat2, lon2):
    """Calculate course using two points"""

    # Convert coordinates to radians
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])

    # Compute initial bearing
    dLon = lon2 - lon1
    y = sin(dLon) * cos(lat2)
    x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
    bearing = degrees(atan2(y, x))
    init_bearing = (bearing + 360) % 360
    print(init_bearing)

    # Compute Final bearing
    dLon = lon1 - lon2
    y = sin(dLon) * cos(lat2)
    x = cos(lat2) * sin(lat1) - sin(lat2) * cos(lat1) * cos(dLon)
    bearing = degrees(atan2(y, x))
    bearing = (bearing + 360) % 360
    final_bearng = (bearing + 180) % 360
    print(final_bearng)

    # Taking the difference
    course = np.round((final_bearng - init_bearing), 4)
    return course


##############################################################
lat1, lon1 = 5.436018, 84.693025
lat2, lon2 = 5.436043, 81.693025
# lat2, lon2 = 5.455943, 84.791008

course = compute_course(lat1, lon1, lat2, lon2)
print(course)
